"""Plugin interface for Jac."""

from __future__ import annotations

from .default import Architype, DSFunc, hookimpl

__all__ = ["Architype", "DSFunc", "hookimpl"]
