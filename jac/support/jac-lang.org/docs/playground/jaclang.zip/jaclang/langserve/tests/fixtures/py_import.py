"""This is a helper file."""


def add1():
    return 1 + 1


def sub1():
    return 1 - 1


# classes
class Orange1:
    def __init__(self):
        self.orange = 1

    def get_orange(self):
        return self.orange

    def set_orange(self, orange):
        self.orange = orange


# variables
orange2 = 1
apple = 1
