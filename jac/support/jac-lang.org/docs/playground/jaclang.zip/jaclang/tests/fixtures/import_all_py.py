"""Module used for testing from x import * in jac."""

from math import *  # noqa


def custom_func(x: int) -> str:
    """Dummy custom function for testing purposes."""  # noqa
    return str(x)
